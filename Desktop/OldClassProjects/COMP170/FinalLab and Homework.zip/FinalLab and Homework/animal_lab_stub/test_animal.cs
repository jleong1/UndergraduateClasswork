using System;

namespace IntroCS
{
   public class TestAnimal
   {
      /// Thoroughly test all Animal methods, with all the actions 
      ///   clearly labeled for a person *not* readingthe code.
      public static void Main()
      {  
         Console.WriteLine("TestAnimal still needs to be implemented");
      }
   }
}