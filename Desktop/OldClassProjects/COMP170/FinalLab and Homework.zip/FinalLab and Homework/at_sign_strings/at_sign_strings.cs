using System; 

class AtSignStringTest
{
   static void Main()
   {
      Console.WriteLine(@"Windows path: c:\Users\aharrin");
      Console.WriteLine(@"a
bc
    
def");
   }
}
