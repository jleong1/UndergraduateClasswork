using System;

class Birthday3
{
   static void Main()
   {   
       HappyBirthdayEmily();
       HappyBirthdayAndre();
   }

   static void HappyBirthdayEmily()
   {
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday, dear Emily.");
      Console.WriteLine ("Happy Birthday to you!");
   }

   static void HappyBirthdayAndre()
   {   
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday, dear Andre.");
      Console.WriteLine ("Happy Birthday to you!");
   }
}
