using System;

class Hello
{
	static void Main()
	{
		Console.WriteLine("Hello World!");
	}
}
