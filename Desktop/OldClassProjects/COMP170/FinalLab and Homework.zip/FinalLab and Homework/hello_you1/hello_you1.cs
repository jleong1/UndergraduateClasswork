using System;

class HelloYou1
{
    static void Main ()
    {   
        Console.WriteLine ("What is your name?");
        string name = Console.ReadLine ();
        Console.WriteLine ("Hello, " + name + "!");
    }

}


