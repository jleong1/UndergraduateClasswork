//Test yourself!  What happens?

using System;

class TestWhile1
{
   static void Main()
   {                  // main chunk
      int i = 4;
      while (i < 9) {
         Console.WriteLine(i);
         i = i + 2;
      }
   }                  // past main chunk
}
