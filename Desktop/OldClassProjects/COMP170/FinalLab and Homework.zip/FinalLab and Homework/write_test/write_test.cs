using System; 

class WriteTest
{
   static void Main()
   {
      string s = "hello";
      Console.Write(s);
      Console.Write("there");
      Console.WriteLine(s);
      Console.WriteLine( "Another line");
      Console.Write("Starting ");
      Console.WriteLine("yet another line");
   }
}
