using System;

namespace GradeCalculation2
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

