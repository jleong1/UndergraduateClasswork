using System;

namespace IntroCS
{
   public class Animal
   {
      
      
   }
}