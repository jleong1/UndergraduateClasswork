using System;

class Birthday1
{
   static void Main ()
   {
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday, dear Emily.");
      Console.WriteLine ("Happy Birthday to you!");
   }
}
