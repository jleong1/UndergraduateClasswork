using System;

class Birthday2
{
   static void HappyBirthdayEmily()
   {
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday to you!");
      Console.WriteLine ("Happy Birthday, dear Emily.");
      Console.WriteLine ("Happy Birthday to you!");
   }

   static void Main()
   {   
      HappyBirthdayEmily();
      Console.WriteLine ("Hip hip hooray!");
      HappyBirthdayEmily();
   }
}
