using System;

class DoTheMath {
   static void Main() {
      // Prompt the user for the numerator using
      //   Console.WriteLine().

      // Convert this text into int numerator using
      // int.Parse().

      // Do the same for the denominator.

      // Calculate quotient and remainder (as integers)
      // Use Console.WriteLine() to make the results pretty as
      // above.

      // Do the same but using floating point division and not
      // doing the remainder calculation.
   }
}

