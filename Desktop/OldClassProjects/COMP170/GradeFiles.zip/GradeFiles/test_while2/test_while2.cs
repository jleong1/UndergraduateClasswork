//Test yourself!  What happens?

using System;

class TestWhile2
{
   static void Main()
   {                  // main chunk
      int i = 4; //variation on TestWhile1.cs
      while (i < 9) {
         i = i + 2;
         Console.WriteLine(i);
      }
   }                  // past main chunk
}


