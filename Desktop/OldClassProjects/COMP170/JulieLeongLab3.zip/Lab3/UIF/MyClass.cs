using System;

namespace IntroCs
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

