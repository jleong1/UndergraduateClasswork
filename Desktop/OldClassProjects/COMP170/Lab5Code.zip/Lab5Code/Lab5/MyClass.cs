using System;

namespace Lab5
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

