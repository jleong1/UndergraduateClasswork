using System;

namespace djr
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

